# Neural Explorer v1.0

Laboratório educativo gratuito do New Era Labs / Divisão 7. Interface em português, responsiva, sem dependências, backend, autenticação ou APIs de execução.

## Executar

Na pasta deste projeto, execute `python -m http.server 8080` e abra http://localhost:8080. É necessário servir por HTTP por causa dos módulos JavaScript; abrir index.html diretamente pode bloquear os módulos no navegador. A aplicação não faz chamadas externas para executar experimentos.

## Publicar no GitHub Pages

Envie apenas o conteúdo desta pasta para um repositório próprio. Em Settings → Pages, selecione Deploy from a branch, a branch desejada e a pasta raiz. Os caminhos são relativos e funcionam em subdiretórios. Não há etapa de compilação. Nenhuma publicação foi executada automaticamente.

## Módulos

- Anatomia: oito estruturas selecionáveis por mouse, toque ou teclado, zoom, rótulos e visão funcional.
- Potencial de ação: Hodgkin–Huxley clássico a 6,3 °C, integração com passo de 0,01 ms e atualização exponencial das comportas; corrente em µA/cm², tempo em ms e tensão em mV. Gráfico de janela móvel de 80 ms. Iniciar aplica trem periódico; pausar preserva estado; reiniciar limpa estado; pulso manual inicia reprodução quando pausado. Ajustes afetam pulsos futuros. Pulsos sobrepostos não somam suas correntes.
- Condução: estimativas empíricas aproximadas v=6d e v=0,5√d, d em µm, v em m/s. Animação 100 vezes mais lenta. Sem modelo de cabo espacial.
- Sinapse: respostas lineares de dupla exponencial com constantes 2 e 15 ms. Excitação e inibição são exemplos de efeito; sem dinâmica vesicular ou potencial de ação.
- Rede: cadeia A→B→C, eventos discretos e limiares didáticos declarados, sem aprendizado ou integração biofísica.

## Validação

Execute `npm test` com Node.js 18 ou posterior. Testes verificam repouso, resposta sublimiar, pico, hiperpolarização, estabilidade, condução, soma sináptica e bloqueio inibitório. Verifique também teclado, zoom, dimensões móveis e controles no navegador.

## Estrutura e fontes

`js/action-potential.js`: membrana; `js/models.js`: modelos simplificados; `js/charts.js`: gráficos; `js/app.js`: estado, controles e renderização; `data/content.js`: conteúdo anatômico. Estado em memória, sem rastreamento ou armazenamento pessoal. Todos os recursos visuais são SVG/CSS locais.

Referência principal: [Neuronal Dynamics, seção 2.2](https://neuronaldynamics.epfl.ch/online/Ch2.S2.html). [Modelo original no Physiome](https://models.physiomeproject.org/exposure/c94a51d2f7bc05f4221e1413a26b63ed/hodgkin_huxley_1952.cellml/docgen). Modelo educativo, não clínico. O limiar varia; −55 mV é apenas guia visual. Morfologia esquemática, fora de escala, não universal.

O arquivo de briefing recebido termina no requisito científico do módulo II. Os módulos adicionais implementam o objetivo geral com escopo e limitações documentados.

## Isolamento

A pasta Neural-Explorer estava vazia na inspeção inicial. O registro verificável foi salvo fora dela na área de artefatos da sessão. Nenhum arquivo de outros projetos foi alterado.

## Licença

MIT, conforme LICENSE. Identidade e marcas dos respectivos titulares.
