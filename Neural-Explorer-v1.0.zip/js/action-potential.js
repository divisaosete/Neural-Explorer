// Hodgkin–Huxley clássico, unidades: ms, mV, µA/cm². Temperatura: 6,3 °C.
const ratio = (x, scale) => Math.abs(x) < 1e-7 ? scale : x / (1 - Math.exp(-x / scale));
function rates(v) { return [0.1*ratio(v+40,10),4*Math.exp(-(v+65)/18),0.07*Math.exp(-(v+65)/20),1/(1+Math.exp(-(v+35)/10)),0.01*ratio(v+55,10),0.125*Math.exp(-(v+65)/80)]; }
export class Membrane {
 constructor(){this.reset();}
 reset(){this.v=-65; const [a,b,c,d,e,f]=rates(this.v);this.m=a/(a+b);this.h=c/(c+d);this.n=e/(e+f);this.t=0;}
 step(current,dt=0.01){const [a,b,c,d,e,f]=rates(this.v);for(const [key,alpha,beta] of [['m',a,b],['h',c,d],['n',e,f]])this[key]=alpha/(alpha+beta)+(this[key]-alpha/(alpha+beta))*Math.exp(-dt*(alpha+beta));const na=120*this.m**3*this.h*(this.v-50),k=36*this.n**4*(this.v+77),leak=0.3*(this.v+54.387);this.v+=dt*(current-na-k-leak);this.t+=dt;return this.v;}
}
export function simulate({intensity=10,duration=1,interval=15,total=60,pulses=2}={}){const cell=new Membrane(),points=[];for(let i=0;i<total*100;i++){const t=i/100;let current=0;for(let p=0;p<pulses;p++)if(t>=5+p*interval&&t<5+p*interval+duration)current=intensity;cell.step(current);if(i%10===0)points.push({t,v:cell.v,current});}return points;}
