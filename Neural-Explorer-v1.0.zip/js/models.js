// Modèles de comparaison pédagogiques, sans prétention de prédiction clinique.
export function conduction(diameter,myelin,length=100){const speed=myelin?6*diameter:0.5*Math.sqrt(diameter);return {speed,delay:length/speed};}
export function synapse({weight=1,inhibitory=false,count=3,spacing=5}={}){let v=-65;const points=[];for(let t=0;t<=100;t+=0.25){let drive=0;for(let j=0;j<count;j++){const age=t-10-j*spacing;if(age>=0)drive+=(inhibitory?-1:1)*weight*3*(Math.exp(-age/15)-Math.exp(-age/2));}v=-65+drive;points.push({t,v});}return points;}
export function network(weight=1,inhibitory=false){const spikes=[[10,30,50],[],[]];for(const t of spikes[0])if(weight>=0.65)spikes[1].push(t+5);for(const t of spikes[1])if(!inhibitory&&weight>=0.9)spikes[2].push(t+5);return spikes;}
